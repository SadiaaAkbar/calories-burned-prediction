# Video Script (4–5 min) — Calories Burned Predictor

## 1. Intro — the problem (45–60s)
"Hi, I'm [name]. For my ML portfolio capstone, I wanted to solve something
I'm genuinely curious about — fitness data. Most apps estimate calories
burned with a really basic formula: just heart rate times duration. I wanted
to see if I could build something more accurate using a fuller picture of a
workout — body composition, workout type, and heart-rate intensity — and
ship it as something you can actually try live."

## 2. The data & process, briefly (60–90s)
- Show the dataset schema for a few seconds: "978 gym sessions — age,
  weight, height, heart rate, workout type, duration, and calories burned
  as the target."
- Show `figures/eda_overview.png` on screen: "Duration and average heart
  rate were the strongest predictors, which matches what you'd expect
  physiologically."
- Mention feature engineering in one sentence: "I added a heart-rate-reserve
  intensity feature — basically, what % of your max effort you were working
  at — since that's more meaningful than raw BPM."
- Show `models/model_comparison.csv` or the printed table: "I trained six
  models — linear, ridge, lasso, random forest, gradient boosting, and SVR —
  and compared them with cross-validation. Gradient Boosting won, explaining
  about 95% of the variance with an average error of just 60 calories."

## 3. Live demo (90–120s)
- Open the deployed Streamlit app.
- Fill in your own real stats (age, weight, height, a workout type you
  actually do).
- Click predict, show the output and the peer-comparison chart.
- Change one variable (e.g. bump duration or switch workout type to HIIT)
  and re-predict to show the model responding sensibly — this is the most
  convincing part of the demo, so don't rush it.

## 4. Wrap-up — what you learned (30–45s)
"The biggest thing I learned was [pick one, genuinely]:
  - how much cleaner feature engineering (like HR intensity ratios) can beat
    throwing raw features at a complex model, or
  - how much model comparison matters — the simple linear model was already
    at 91% R², and it took real evaluation to justify the added complexity
    of gradient boosting, or
  - how different building something end-to-end (data to deployment) is
    from just training a model in a notebook.
Link to the code and live app are below — thanks for watching."

## Filming tips
- Record the app demo screen capture first (it's the part people care most
  about), then record your talking intro/outro separately and edit together.
- Keep the EDA/model-comparison section brief — it's there to show rigor,
  not to teach a course. 60–90 seconds max.
- End on the live app, not on a slide — it's more memorable and proves it
  actually works.

## LinkedIn caption draft
"🔥 Built an end-to-end ML project: a Calories Burned Predictor that beats
typical wearable formulas by using body composition + heart-rate intensity,
not just duration. Went from raw data → EDA → feature engineering →
comparing 6 models → deploying a live Streamlit app anyone can try.
Gradient Boosting won out at 95% R² / ~60 kcal average error.
Biggest takeaway: [your genuine one-liner].
Try it live: [app link] | Code: [repo link]
#MachineLearning #DataScience #Portfolio
@Neurofive Solutions"
